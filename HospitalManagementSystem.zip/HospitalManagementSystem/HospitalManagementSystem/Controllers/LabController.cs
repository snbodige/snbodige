﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalManagementSystem.Repositories;
using HospitalManagementSystem.Models;


namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LabController : ControllerBase
    {
        private LabRepository LabRepository;
        public LabController()
        {
            LabRepository = new LabRepository();
        }


        [HttpPost, Route("AddLabs")]

        public IActionResult Add(Lab labs)
        {
            LabRepository.AddLabs(labs);
            return StatusCode(200, "Labs Added");
        }


        [HttpGet, Route("GetAllLabs")]

        public IActionResult Getall()
        {
            return StatusCode(200, LabRepository.GetLabs());

        }


        [HttpGet, Route("GetLabsById/{id}")]
        public IActionResult Get(string id)
        {
            return StatusCode(200, LabRepository.GetLabs(id));

        }

        [HttpPut, Route("EditLabs")]

        public IActionResult Edit(Lab labs)
        {
            LabRepository.EditLabs(labs);
            return StatusCode(200, "Record Edited");

        }


        [HttpDelete, Route("DeleteLabs/{id}")]

        public IActionResult Delete(string id)
        {
            LabRepository.DeleteLabs(id);
            return StatusCode(200);

        }



    }
}