﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalManagementSystem.Repositories;
using HospitalManagementSystem.Models;



namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BilldataController : ControllerBase
    {
        private BilldataRepository BilldataRepository;
        public BilldataController()
        {
            BilldataRepository = new BilldataRepository();
        }



        [HttpPut, Route("EditBilldata")]

        public IActionResult Edit(BillData billdata)
        {
            BilldataRepository.EditBilldata(billdata);
            return StatusCode(200, "Bill Edited");

        }





        [HttpGet, Route("GetAllBilldata")]

        public IActionResult Getall()
        {
            return StatusCode(200, BilldataRepository.GetBilldata());

        }






        [HttpGet, Route("GetBilldataById/{id}")]
        public IActionResult Get(string id)
        {
            return StatusCode(200, BilldataRepository.GetBilldata(id));

        }




        [HttpPost, Route("AddBilldata")]

        public IActionResult Add(BillData billdata)
        {
            BilldataRepository.AddBilldata(billdata);
            return StatusCode(200, "Bill Added");
        }



        [HttpDelete, Route("DeleteBilldata/{id}")]

        public IActionResult Delete(string id)
        {
            BilldataRepository.DeleteBilldata(id);
            return StatusCode(200);

        }

    }
}
