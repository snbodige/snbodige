﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalManagementSystem.Repositories;
using HospitalManagementSystem.Models;


namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomDataController : ControllerBase
    {

        private RoomDataRepository RoomDataRepository;
        public RoomDataController()
        {
            RoomDataRepository = new RoomDataRepository();
        }


        [HttpPost, Route("AddRoomData")]

        public IActionResult Add(RoomData RoomData)
        {
            RoomDataRepository.AddRoomData(RoomData);
            return StatusCode(200, "RoomData Added");
        }




        [HttpPut, Route("EditRoomData")]

        public IActionResult Edit(RoomData RoomData)
        {
            RoomDataRepository.EditRoomData(RoomData);
            return StatusCode(200, "Data Edited");

        }

        [HttpGet, Route("GetAllRoomData")]

        public IActionResult Getall()
        {
            return StatusCode(200, RoomDataRepository.GetRoomData());

        }



        [HttpGet, Route("GetRoomDataById/{id}")]
        public IActionResult Get(string id)
        {
            return StatusCode(200, RoomDataRepository.GetRoomData(id));

        }


        [HttpDelete, Route("DeleteRoomData/{id}")]

        public IActionResult Delete(string id)
        {
            RoomDataRepository.DeleteRoomData(id);
            return StatusCode(200, "Deleted");

        }



    }
}