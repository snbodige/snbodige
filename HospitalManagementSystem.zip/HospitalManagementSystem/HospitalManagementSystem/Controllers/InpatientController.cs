﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalManagementSystem.Repositories;
using HospitalManagementSystem.Models;


namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InPatientController : ControllerBase
    {
        private InPatientRepository InPatientRepository;
        public InPatientController()
        {
            InPatientRepository = new InPatientRepository();
        }





        [HttpPost, Route("AddInpatient")]

        public IActionResult Add(Inpatient inpatient)
        {
            InPatientRepository.AddInpatient(inpatient);
            return StatusCode(200, "Inpatient Added");
        }






        [HttpPut, Route("EditInpatient")]

        public IActionResult Edit(Inpatient inpatient)
        {
            InPatientRepository.EditInpatients(inpatient);
            return StatusCode(200, "Inpatient Edited");

        }





        [HttpGet, Route("GetAllInpatients")]

        public IActionResult Getall()
        {
            return StatusCode(200, InPatientRepository.GetInpatients());

        }


        [HttpGet, Route("GetInpatientsById/{id}")]
        public IActionResult Get(string id)
        {
            return StatusCode(200, InPatientRepository.GetInpatients(id));

        }




        [HttpDelete, Route("DeleteInpatient/{id}")]

        public IActionResult Delete(string id)
        {
            InPatientRepository.DeleteInpatients(id);
            return StatusCode(200);

        }





        [HttpGet, Route("GetInPatientByAdmissionDate/admissiondate")]
        public IActionResult GetInpatient(DateTime admissionDate)
        {

            return StatusCode(200, InPatientRepository.GetInPatientByAdmissionDate(admissionDate));
        }





        [HttpGet, Route("GetInPatientByDischargeDate/dischargeDate")]
        public IActionResult GetInpatients(DateTime dischargeDate)
        {

            return StatusCode(200, InPatientRepository.GetInPatientByDischargeDate(dischargeDate));
        }









    }
}