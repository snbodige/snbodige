﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalManagementSystem.Repositories;
using HospitalManagementSystem.Models;



namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private PatientRepository PatientRepository;
        public PatientController()
        {
            PatientRepository = new PatientRepository();
        }



        [HttpPost, Route("AddPatient")]

        public IActionResult Add(Patient patient)
        {
            PatientRepository.AddPatient(patient);
            return StatusCode(200, "Patient Added");
        }

        [HttpPut, Route("EditPatient")]

        public IActionResult Edit(Patient patient)
        {
            PatientRepository.EditPatient(patient);
            return StatusCode(200, "Record Edited");

        }




        [HttpGet, Route("GetAllPatients")]

        public IActionResult Getall()
        {
            return StatusCode(200, PatientRepository.GetPatients());

        }





        [HttpGet, Route("GetPatientById/{id}")]
        public IActionResult Get(string id)
        {
            return StatusCode(200, PatientRepository.GetPatients(id));

        }

        [HttpDelete, Route("DeletePatients/{id}")]

        public IActionResult Delete(string id)
        {
            PatientRepository.DeletePatients(id);
            return StatusCode(200);

        }

        //[HttpGet, Route("GetPatientsDetailsByDoctorId/doctorsId")]
        //public IActionResult GetPatient(string doctorId)
        //{

        //    return StatusCode(200, PatientRepository.GetPatientsDetailsByDoctorId(doctorId));
        //}






    }
}