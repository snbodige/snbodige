﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalManagementSystem.Repositories;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OutPatientController : ControllerBase
    {
        private OutPatientRepository OutpatientRepository;
        public OutPatientController()
        {
            OutpatientRepository = new OutPatientRepository();
        }

        [HttpPost, Route("AddOutpatient")]

        public IActionResult Add(Outpatient outpatient)
        {
            OutpatientRepository.AddOutpatient(outpatient);
            return StatusCode(200, "Outpatient Added");
        }


        [HttpPut, Route("EditOutpatient")]

        public IActionResult Edit(Outpatient outpatient)
        {
            OutpatientRepository.EditOutpatients(outpatient);
            return StatusCode(200, "Outpatient Edited");


        }

        [HttpGet, Route("GetAllOutpatients")]

        public IActionResult Getall()
        {
            return StatusCode(200, OutpatientRepository.GetOutpatients());

        }


        [HttpGet, Route("GetOutpatientsById/{id}")]
        public IActionResult Get(string id)
        {
            return StatusCode(200, OutpatientRepository.GetOutpatients(id));

        }

        [HttpDelete, Route("DeleteOutpatient/{id}")]

        public IActionResult Delete(string id)
        {
            OutpatientRepository.DeleteOutpatients(id);
            return StatusCode(200);

        }

    }
}