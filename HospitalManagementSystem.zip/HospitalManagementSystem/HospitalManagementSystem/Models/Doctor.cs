﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalManagementSystem.Models
{
    public partial class Doctor
    {
        public Doctor()
        {
            BillData = new HashSet<BillData>();
            Inpatients = new HashSet<Inpatient>();
            Labs = new HashSet<Lab>();
            Outpatients = new HashSet<Outpatient>();
            Patients = new HashSet<Patient>();
            RoomData = new HashSet<RoomData>();
        }

        public string DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string DoctorDept { get; set; }

        public virtual ICollection<BillData> BillData { get; set; }
        public virtual ICollection<Inpatient> Inpatients { get; set; }
        public virtual ICollection<Lab> Labs { get; set; }
        public virtual ICollection<Outpatient> Outpatients { get; set; }
        public virtual ICollection<Patient> Patients { get; set; }
        public virtual ICollection<RoomData> RoomData { get; set; }
    }
}
