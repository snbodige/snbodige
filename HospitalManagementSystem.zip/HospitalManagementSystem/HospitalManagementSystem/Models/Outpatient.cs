﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalManagementSystem.Models
{
    public partial class Outpatient
    {
        public string OutpId { get; set; }
        public string Pid { get; set; }
        public DateTime? TreatmentDate { get; set; }
        public string DoctorId { get; set; }
        public string LabNo { get; set; }

        public virtual Doctor Doctor { get; set; }
        public virtual Lab LabNoNavigation { get; set; }
        public virtual Patient PidNavigation { get; set; }
    }
}
