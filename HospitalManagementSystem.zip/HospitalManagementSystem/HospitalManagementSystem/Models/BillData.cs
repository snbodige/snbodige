﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalManagementSystem.Models
{
    public partial class BillData
    {
        public string BillNo { get; set; }
        public string Pid { get; set; }
        public string PatientType { get; set; }
        public string DoctorId { get; set; }
        public int? DoctorFees { get; set; }
        public int? RoomCharge { get; set; }
        public int? OperationCharges { get; set; }
        public int? MedicineFees { get; set; }
        public int? TotalDays { get; set; }
        public int? LabFees { get; set; }
        public int? TotalAmount { get; set; }

        public virtual Doctor Doctor { get; set; }
        public virtual Patient PidNavigation { get; set; }
    }
}
