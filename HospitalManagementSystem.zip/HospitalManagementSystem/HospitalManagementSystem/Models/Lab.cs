﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalManagementSystem.Models
{
    public partial class Lab
    {
        public Lab()
        {
            Inpatients = new HashSet<Inpatient>();
            Outpatients = new HashSet<Outpatient>();
            RoomData = new HashSet<RoomData>();
        }

        public string LabId { get; set; }
        public string Pid { get; set; }
        public string DoctorId { get; set; }
        public DateTime? TestDate { get; set; }
        public string TestType { get; set; }
        public string PatientType { get; set; }

        public virtual Doctor Doctor { get; set; }
        public virtual Patient PidNavigation { get; set; }
        public virtual ICollection<Inpatient> Inpatients { get; set; }
        public virtual ICollection<Outpatient> Outpatients { get; set; }
        public virtual ICollection<RoomData> RoomData { get; set; }
    }
}
