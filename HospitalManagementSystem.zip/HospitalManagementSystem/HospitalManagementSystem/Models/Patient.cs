﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalManagementSystem.Models
{
    public partial class Patient
    {
        public Patient()
        {
            BillData = new HashSet<BillData>();
            Inpatients = new HashSet<Inpatient>();
            Labs = new HashSet<Lab>();
            Outpatients = new HashSet<Outpatient>();
        }

        public string PatientId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int? Weight { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }
        public string Disease { get; set; }
        public string DoctorId { get; set; }

        public virtual Doctor Doctor { get; set; }
        public virtual ICollection<BillData> BillData { get; set; }
        public virtual ICollection<Inpatient> Inpatients { get; set; }
        public virtual ICollection<Lab> Labs { get; set; }
        public virtual ICollection<Outpatient> Outpatients { get; set; }
    }
}
