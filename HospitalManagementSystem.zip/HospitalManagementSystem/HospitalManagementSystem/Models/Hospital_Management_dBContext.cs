﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace HospitalManagementSystem.Models
{
    public partial class Hospital_Management_dBContext : DbContext
    {
        public Hospital_Management_dBContext()
        {
        }

        public Hospital_Management_dBContext(DbContextOptions<Hospital_Management_dBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BillData> BillData { get; set; }
        public virtual DbSet<Doctor> Doctors { get; set; }
        public virtual DbSet<Inpatient> Inpatients { get; set; }
        public virtual DbSet<Lab> Labs { get; set; }
        public virtual DbSet<Outpatient> Outpatients { get; set; }
        public virtual DbSet<Patient> Patients { get; set; }
        public virtual DbSet<RoomData> RoomData { get; set; }
       

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("server=ACER-PC;database=Hospital_Management_dB;trusted_connection=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<BillData>(entity =>
            {
                entity.HasKey(e => e.BillNo)
                    .HasName("PK__BillData__11F28419D56F16C1");

                entity.Property(e => e.BillNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PatientType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Pid)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("PId");

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.BillData)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK__BillData__Doctor__1DE57479");

                entity.HasOne(d => d.PidNavigation)
                    .WithMany(p => p.BillData)
                    .HasForeignKey(d => d.Pid)
                    .HasConstraintName("FK__BillData__PId__1CF15040");
            });

            modelBuilder.Entity<Doctor>(entity =>
            {
                entity.ToTable("Doctor");

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("doctorId");

                entity.Property(e => e.DoctorDept)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("doctorDept");

                entity.Property(e => e.DoctorName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("doctorName");
            });

            modelBuilder.Entity<Inpatient>(entity =>
            {
                entity.HasKey(e => e.InpId)
                    .HasName("PK__Inpatien__9F4BA0FFAA08A1F6");

                entity.ToTable("Inpatient");

                entity.Property(e => e.InpId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.AdmissionDate).HasColumnType("date");

                entity.Property(e => e.DischargeDate).HasColumnType("date");

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.LabNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Pid)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("PId");

                entity.Property(e => e.RoomNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.Inpatients)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK__Inpatient__Docto__22AA2996");

                entity.HasOne(d => d.LabNoNavigation)
                    .WithMany(p => p.Inpatients)
                    .HasForeignKey(d => d.LabNo)
                    .HasConstraintName("FK__Inpatient__LabNo__239E4DCF");

                entity.HasOne(d => d.PidNavigation)
                    .WithMany(p => p.Inpatients)
                    .HasForeignKey(d => d.Pid)
                    .HasConstraintName("FK__Inpatient__PId__20C1E124");

                entity.HasOne(d => d.RoomNoNavigation)
                    .WithMany(p => p.Inpatients)
                    .HasForeignKey(d => d.RoomNo)
                    .HasConstraintName("FK__Inpatient__RoomN__21B6055D");
            });

            modelBuilder.Entity<Lab>(entity =>
            {
                entity.ToTable("Lab");

                entity.Property(e => e.LabId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PatientType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Pid)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("PId");

                entity.Property(e => e.TestDate).HasColumnType("date");

                entity.Property(e => e.TestType)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.Labs)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK__Lab__DoctorId__164452B1");

                entity.HasOne(d => d.PidNavigation)
                    .WithMany(p => p.Labs)
                    .HasForeignKey(d => d.Pid)
                    .HasConstraintName("FK__Lab__PId__15502E78");
            });

            modelBuilder.Entity<Outpatient>(entity =>
            {
                entity.HasKey(e => e.OutpId)
                    .HasName("PK__Outpatie__2B3505B9C2535DAF");

                entity.ToTable("Outpatient");

                entity.Property(e => e.OutpId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.LabNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Pid)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("PId");

                entity.Property(e => e.TreatmentDate).HasColumnType("date");

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.Outpatients)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK__Outpatien__Docto__276EDEB3");

                entity.HasOne(d => d.LabNoNavigation)
                    .WithMany(p => p.Outpatients)
                    .HasForeignKey(d => d.LabNo)
                    .HasConstraintName("FK__Outpatien__LabNo__286302EC");

                entity.HasOne(d => d.PidNavigation)
                    .WithMany(p => p.Outpatients)
                    .HasForeignKey(d => d.Pid)
                    .HasConstraintName("FK__Outpatient__PId__267ABA7A");
            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.ToTable("Patient");

                entity.Property(e => e.PatientId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Address)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Disease)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNo)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.Patients)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK__Patient__DoctorI__1273C1CD");
            });

            modelBuilder.Entity<RoomData>(entity =>
            {
                entity.HasKey(e => e.RoomNo)
                    .HasName("PK__RoomData__328651AA20097FCC");

                entity.Property(e => e.RoomNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DoctorId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.LabNo)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TreatmentDate).HasColumnType("date");

                entity.HasOne(d => d.Doctor)
                    .WithMany(p => p.RoomData)
                    .HasForeignKey(d => d.DoctorId)
                    .HasConstraintName("FK__RoomData__Doctor__1920BF5C");

                entity.HasOne(d => d.LabNoNavigation)
                    .WithMany(p => p.RoomData)
                    .HasForeignKey(d => d.LabNo)
                    .HasConstraintName("FK__RoomData__LabNo__1A14E395");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
