﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using HospitalManagementSystem.Models;


namespace HospitalManagementSystem.Repositories
{
    public class OutPatientRepository
    {

        private readonly Hospital_Management_dBContext context;

        public OutPatientRepository()
        {
            context = new Hospital_Management_dBContext();

        }

        public void AddOutpatient(Outpatient outpatient)
        {
            context.Outpatients.Add(outpatient);
            context.SaveChanges();
        }




        public void EditOutpatients(Outpatient outpatient)
        {
            context.Outpatients.Update(outpatient);
            context.SaveChanges();
        }
        public List<Outpatient> GetOutpatients()
        {
            return context.Outpatients.ToList();

        }
        public Outpatient GetOutpatients(string id)
        {
            Outpatient outpatients = context.Outpatients.Find(id);
            return outpatients;
        }
        public void DeleteOutpatients(string id)
        {
            Outpatient outpatients = context.Outpatients.Find(id);
            context.Outpatients.Remove(outpatients);
            context.SaveChanges();
        }
    }
}














