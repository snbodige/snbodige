﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Repositories
{
    public class LabRepository
    {
        private readonly Hospital_Management_dBContext context;
        public LabRepository()
        {
            context = new Hospital_Management_dBContext();

        }
        public void AddLabs(Lab lab)
        {
            context.Labs.Add(lab);
            context.SaveChanges();
        }

        public void EditLabs(Lab lab)
        {
            context.Labs.Update(lab);
            context.SaveChanges();
        }




        public List<Lab> GetLabs()
        {
            return context.Labs.ToList();

        }



        public Lab GetLabs(string id)
        {
            Lab labs = context.Labs.Find(id);
            return labs;
        }



        public void DeleteLabs(string id)
        {
            Lab labs = context.Labs.Find(id);
            context.Labs.Remove(labs);
            context.SaveChanges();
        }

    }
}
























