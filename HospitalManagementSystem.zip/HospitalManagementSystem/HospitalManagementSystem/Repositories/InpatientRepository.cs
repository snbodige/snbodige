﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using HospitalManagementSystem.Models;


namespace HospitalManagementSystem.Repositories
{
    public class InPatientRepository
    {
        private readonly Hospital_Management_dBContext context;
        public InPatientRepository()
        {
            context = new Hospital_Management_dBContext();

        }
        public void AddInpatient(Inpatient inpatient)
        {
            context.Inpatients.Add(inpatient);
            context.SaveChanges();
        }



        public void EditInpatients(Inpatient inpatient)
        {
            context.Inpatients.Update(inpatient);
            context.SaveChanges();
        }




        //public List<Inpatient> GetInpatients(DateTime dischargeDate)
        //{
        //    return context.Inpatients.ToList();

        //}


        //public Inpatient GetInpatients(Inpatient inpatient)
        //{
        //    Inpatient inpatients = Get(Inpatient);
        //    return inpatients;
        //}




        public List<Inpatient> GetInpatients()
        {
            return context.Inpatients.ToList();

        }




        public Inpatient GetInpatients(string id)
        {
            Inpatient inpatients = context.Inpatients.Find(id);
            return inpatients;
        }



        public void DeleteInpatients(string id)
        {
            Inpatient inpatients = context.Inpatients.Find(id);
            context.Inpatients.Remove(inpatients);
            context.SaveChanges();
        }




        public Inpatient GetInPatientByAdmissionDate(DateTime admissionDate)    //get Inpatient details using admission date

        {
            Inpatient inpatient = context.Inpatients.SingleOrDefault(a => a.AdmissionDate == admissionDate);
            return inpatient;
        }




        public Inpatient GetInPatientByDischargeDate(DateTime dischargeDate)//get inpatient details using discharge date

        {
            Inpatient inpatient = context.Inpatients.SingleOrDefault(d => d.DischargeDate == dischargeDate);
            return inpatient;
        }




    }
}