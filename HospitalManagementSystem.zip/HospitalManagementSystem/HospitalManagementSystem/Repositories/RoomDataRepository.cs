﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using HospitalManagementSystem.Models;


namespace HospitalManagementSystem.Repositories
{
    public class RoomDataRepository
    {

        private readonly Hospital_Management_dBContext context;

        public RoomDataRepository()
        {
            context = new Hospital_Management_dBContext();

        }
        public void AddRoomData(RoomData RoomData)
        {
            context.RoomData.Add(RoomData);
            context.SaveChanges();
        }

        public void EditRoomData(RoomData RoomData)
        {
            context.RoomData.Update(RoomData);
            context.SaveChanges();
        }




        public List<RoomData> GetRoomData()
        {
            return context.RoomData.ToList();

        }



        public RoomData GetRoomData(string id)
        {
            RoomData RoomData = context.RoomData.Find(id);
            return RoomData;
        }


        public void DeleteRoomData(string id)
        {
            RoomData RoomData = context.RoomData.Find(id);
            context.RoomData.Remove(RoomData);
            context.SaveChanges();
        }


    }
}