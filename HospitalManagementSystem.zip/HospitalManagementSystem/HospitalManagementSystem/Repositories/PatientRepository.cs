﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using HospitalManagementSystem.Models;



namespace HospitalManagementSystem.Repositories
{
    public class PatientRepository
    {
        private readonly Hospital_Management_dBContext context;
        public PatientRepository()
        {
            context = new Hospital_Management_dBContext();

        }



        public void AddPatient(Patient patient)
        {
            context.Patients.Add(patient);
            context.SaveChanges();
        }


        public void EditPatient(Patient patient)
        {
            context.Patients.Update(patient);
            context.SaveChanges();
        }




        public List<Patient> GetPatients()
        {
            return context.Patients.ToList();

        }



        public Patient GetPatients(string id)
        {
            Patient patients = context.Patients.Find(id);
            return patients;
        }



        public void DeletePatients(string id)
        {
            Patient patients = context.Patients.Find(id);
            context.Patients.Remove(patients);
            context.SaveChanges();
        }

        //public Patient GetPatientsDetailsByDoctorId(string doctorId)
        //{
        //    Patient patient = context.Patients.SingleOrDefault(e => e.DoctorId == doctorId);
        //    return patient;
        //}




    }
}