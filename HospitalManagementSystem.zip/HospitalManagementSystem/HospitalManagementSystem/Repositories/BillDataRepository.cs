﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using HospitalManagementSystem.Models;



namespace HospitalManagementSystem.Repositories
{
    public class BilldataRepository
    {
        private readonly Hospital_Management_dBContext context;

        public BilldataRepository()
        {
            context = new Hospital_Management_dBContext();

        }

        public void EditBilldata(BillData billData)
        {
            context.BillData.Update(billData);
            context.SaveChanges();
        }




        public List<BillData> GetBilldata()
        {
            return context.BillData.ToList();

        }



        public BillData GetBilldata(string id)
        {
            BillData billData = context.BillData.Find(id);
            return billData;
        }


        public void AddBilldata(BillData billData)
        {
            context.BillData.Add(billData);
            context.SaveChanges();
        }


        public void DeleteBilldata(string id)
        {
            BillData billData = context.BillData.Find(id);
            context.BillData.Remove(billData);
            context.SaveChanges();
        }



    }
}